package com.example.brannon.primetimemovies.adapter;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;

public abstract class RecyclerViewScrolledListener extends RecyclerView.OnScrollListener {

    private int visibleThreshold = 5;
    private int currentPage = 1;
    private int previousTotal = 0;
    private boolean loading = true;
    private int startingPageIndex = 0;

    RecyclerView.LayoutManager mLayoutManager;

    public RecyclerViewScrolledListener(LinearLayoutManager layoutManager) {
        this.mLayoutManager = layoutManager;
    }

    public RecyclerViewScrolledListener(GridLayoutManager layoutManager){
        this.mLayoutManager = layoutManager;
        visibleThreshold = visibleThreshold * layoutManager.getSpanCount();
    }

    public RecyclerViewScrolledListener(StaggeredGridLayoutManager layoutManager){
        this.mLayoutManager = layoutManager;
        visibleThreshold = visibleThreshold * layoutManager.getSpanCount();
    }

    public int getLastVisible(int[] lastVisibleItemPositions){
        int maxSize = 0;
        for (int i = 0; i < lastVisibleItemPositions.length; i++) {
            if (i ==0) {
                maxSize = lastVisibleItemPositions[i];
            } else if (lastVisibleItemPositions[i] > maxSize){
                maxSize = lastVisibleItemPositions[i];
            }

        }
        return maxSize;
    }

    @Override
    public void onScrolled(RecyclerView view, int dx, int dy) {
        int lastVisibleItemSpot = 0;
        int totalItemCount = mLayoutManager.getItemCount();

        if (mLayoutManager instanceof StaggeredGridLayoutManager){
            int[] lastVisibleItemPositions = ((StaggeredGridLayoutManager) mLayoutManager) .findLastVisibleItemPositions(null);
        }else if (mLayoutManager instanceof GridLayoutManager){
            lastVisibleItemSpot = ((GridLayoutManager) mLayoutManager).findLastVisibleItemPosition();
        }else if (mLayoutManager instanceof LinearLayoutManager){
            lastVisibleItemSpot = ((LinearLayoutManager) mLayoutManager).findLastVisibleItemPosition();
        }
        if (totalItemCount < previousTotal){
            this.currentPage = this.startingPageIndex;
            this.previousTotal = totalItemCount;
            if (totalItemCount == 0){
                this.loading = true;
            }
        }

        if (loading && (totalItemCount > previousTotal)){
            loading = false;
            previousTotal = totalItemCount;
        }
        if (!loading && (lastVisibleItemSpot + visibleThreshold) > totalItemCount) {
            currentPage++;
            onLoadMore(currentPage, totalItemCount, view);
            loading = true;
        }
    }

    public void reset(){
        this.currentPage = 1;
        this.previousTotal = 0;
        this.loading = true;
    }

    public abstract void onLoadMore(int page, int totalItemsCount, RecyclerView view);

    public int getVisibleThreshold(){
        return visibleThreshold;
    }

    public int getCurrentPage(){
        return currentPage;
    }

    public int getPreviousTotal(){
        return previousTotal;
    }

    public boolean isLoading(){
        return loading;
    }

    public int getStartingPageIndex(){
        return startingPageIndex;
    }

    public void setVisibleThreshold(int visibleThreshold){
        this.visibleThreshold = visibleThreshold;
    }

    public void setCurrentPage(int currentPage){
        this.currentPage = currentPage;
    }

    public void setPreviousTotal(int previousTotal){
        this.previousTotal = previousTotal;
    }

    public void setLoading(boolean loading){
        this.loading = loading;
    }

    public void setStartingPageIndex(int startingPageIndex){
        this.startingPageIndex = startingPageIndex;
    }

}
