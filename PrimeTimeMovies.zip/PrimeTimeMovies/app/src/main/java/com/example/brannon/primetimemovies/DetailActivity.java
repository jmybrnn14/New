package com.example.brannon.primetimemovies;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.example.brannon.primetimemovies.Model.Movies;
import com.example.brannon.primetimemovies.adapter.MoviesAdapter;
import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity {

    private ImageView mPoster;
    private TextView mTitle;
    private TextView mReleaseDate;
    private Toolbar mToolbar;
    private TextView mPopularity;
    private TextView mRating;
    private TextView mOverview;
    private CollapsingToolbarLayout mCollapsingToolbarLayout;

    private Movies Movies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.movies_detail);

        mToolbar = findViewById(R.id.details_activity_toolbar);
        mTitle = (TextView) findViewById(R.id.tv_title);
        mPoster = (ImageView) findViewById(R.id.movie_poster);
        mReleaseDate = (TextView) findViewById(R.id.tv_release_date);
        mRating = (TextView) findViewById(R.id.tv_rating);
        mOverview = (TextView) findViewById(R.id.tv_overview);
        mCollapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        mCollapsingToolbarLayout.setTitleEnabled(false);

        String posterImageUrl;

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent intent = getIntent();

        if (intent != null) {
            if (intent.hasExtra(MoviesAdapter.TITLE_INTENT_KEY)) {
                mTitle.setText(intent.getStringExtra(MoviesAdapter.TITLE_INTENT_KEY));
                mReleaseDate.setText(intent.getStringExtra(MoviesAdapter.RELEASE_DATE_INTENT_KEY));
                mPopularity.setText(intent.getStringExtra(MoviesAdapter.POPULARITY_INTENT_KEY));
                mRating.setText(intent.getStringExtra(MoviesAdapter.VOTE_INTENT_KEY));
                mOverview.setText(intent.getStringExtra(MoviesAdapter.OVERVIEW_INTENT_KEY));
                posterImageUrl = "https://image.tmdb.org/t/p/w500" + intent.getStringExtra(MoviesAdapter.POSTER_INTENT_KEY);
                Glide.with(this)
                        .load(posterImageUrl)
                        .into(mPoster);

            }
        }
    }

    private void setSupportActionBar(Toolbar mToolbar) {
    }

    @Override
            public boolean onSupportNavigateUp(){
            onBackPressed();
            return true;









        }

}
