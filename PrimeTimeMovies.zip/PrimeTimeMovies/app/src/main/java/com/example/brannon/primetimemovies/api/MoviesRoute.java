package com.example.brannon.primetimemovies.api;

import com.example.brannon.primetimemovies.Model.MoviesPage;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface MoviesRoute {



    @GET("movie/popular")
    Call<MoviesPage> getPopular(@Query("api_key") String apiMovieKey, @Query("page") int page);

    @GET("movie/top_rated")
    Call<MoviesPage> getTopRated(@Query("api_key") String apiMovieKey, @Query("page") int page);

}
