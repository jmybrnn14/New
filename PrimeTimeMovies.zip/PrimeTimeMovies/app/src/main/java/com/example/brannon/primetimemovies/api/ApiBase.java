package com.example.brannon.primetimemovies.api;

public class ApiBase {

    private static final String API_MOVIE_URL = "https://api.themoviedb.org/3/";
    private static final String API_MOVIE_KEY = "api_key=acaab3f16ba7bd797a963e70b51dd304";

    public static MoviesRoute getMoviesRoute(){
        return MoviesServiceGenerator.getClient(API_MOVIE_URL).create(MoviesRoute.class);
    }

}
