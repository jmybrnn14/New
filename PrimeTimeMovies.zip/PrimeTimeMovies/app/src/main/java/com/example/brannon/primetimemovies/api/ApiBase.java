package com.example.brannon.primetimemovies.api;

public class ApiBase {

    private static final String API_MOVIE_URL = "https://api.themoviedb.org/3/";

    public static MoviesRoute getMoviesRoute(){
        return MoviesConnect.getClient(API_MOVIE_URL).create(MoviesRoute.class);
    }

}
