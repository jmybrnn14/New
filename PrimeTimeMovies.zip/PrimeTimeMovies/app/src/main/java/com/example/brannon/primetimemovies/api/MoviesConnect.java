package com.example.brannon.primetimemovies.api;

import android.net.Uri;

import java.net.URL;

import retrofit2.Converter;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MoviesConnect {

    public static Retrofit apiMovies = null;

    public static Retrofit getClient(String movieUrl) {
        if (apiMovies == null){
            Retrofit.Builder builder = new Retrofit.Builder();
            builder.baseUrl(movieUrl);
            builder.addConverterFactory(GsonConverterFactory.create());
            builder.build();
        }
        return apiMovies;
    }


}
