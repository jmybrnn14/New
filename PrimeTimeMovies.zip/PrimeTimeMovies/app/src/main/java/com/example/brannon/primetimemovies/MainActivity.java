package com.example.brannon.primetimemovies;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.brannon.primetimemovies.Model.Movies;
import com.example.brannon.primetimemovies.Model.MoviesPage;
import com.example.brannon.primetimemovies.adapter.MoviesAdapter;
import com.example.brannon.primetimemovies.adapter.RecyclerViewScrolledListener;
import com.example.brannon.primetimemovies.api.ApiBase;
import com.example.brannon.primetimemovies.api.MoviesRoute;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements SharedPreferences.OnSharedPreferenceChangeListener{

    private static final String TAG = MainActivity.class.getSimpleName();

    private MoviesAdapter mAdapter;
    private MoviesRoute mRoute;
    private RecyclerView mRecyclerView;
    private Toolbar mToolbar;
    private Context mContext;
    private boolean mLoadSavedState;
    private RecyclerViewScrolledListener mScrollListener;
    private String mSortType;

    private static final String CALLBACK_TEXT_KEY = "callback";
    private static final String SCROLL_POSITION_KEY = "position";
    private static final int API_DEFAULT_PAGE = 1;
    private static final String POPULAR_SORT = "popular";
    private static final String TOP_RATED_SORT = "top_rated";
    private static final String PREVIOUS_TOTAL_ITEM_COUNT_KEY = "previous_total_item_count";
    private static final String LOADING_KEY = "loading";
    private static final String CURRENT_PAGE_KEY = "current_page";
    private static final String SORT_TYPE_KEY = "sort_type";
    private static final String MOVIES_LIST_KEY = "movies_list";

    @Override
    protected void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);

        if (mRecyclerView != null){
            //save layout state
            outState.putParcelable(CALLBACK_TEXT_KEY, mRecyclerView.getLayoutManager().onSaveInstanceState());
            outState.putInt(SCROLL_POSITION_KEY, ((GridLayoutManager)mRecyclerView.getLayoutManager()).findLastCompletelyVisibleItemPosition());
            outState.putInt(CURRENT_PAGE_KEY, mScrollListener.getCurrentPage());
            outState.putInt(PREVIOUS_TOTAL_ITEM_COUNT_KEY, mScrollListener.getPreviousTotal());
            outState.putBoolean(LOADING_KEY, mScrollListener.isLoading());
            outState.putString(SORT_TYPE_KEY, mSortType);
            outState.putParcelableArrayList(MOVIES_LIST_KEY, (ArrayList<? extends Parcelable>) mAdapter.getmList());
            logAndAppend("ON_SAVE_INSTANCE_STATE: 1");
        }
    }

    private void logAndAppend(String on_save_instance_state){
        Log.d(TAG, "Lifecycle log: " + on_save_instance_state);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);

        //Retrieve list state and list items
        if (savedInstanceState != null){
            Parcelable savedState = savedInstanceState.getParcelable(CALLBACK_TEXT_KEY);
            logAndAppend("ON_RESTORE_INSTANCE_STATE: 2");
        }
    }

    @Override
    protected void onPause(){
        super.onPause();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       mContext = this;
       mLoadSavedState = false;
       mRoute = ApiBase.getMoviesRoute();
       mRecyclerView = (RecyclerView) findViewById(R.id.contents);
       mToolbar = (Toolbar) findViewById(R.id.toolbar);
       mSortType = POPULAR_SORT;

       setSupportActionBar(mToolbar);
       mAdapter = new MoviesAdapter(this, new ArrayList<Movies>(0), new MoviesAdapter.PostMoviesListener(){

           @Override
           public void onPostClick(long id){
               Toast.makeText(MainActivity.this, "Post id is", Toast.LENGTH_SHORT).show();
           }
       });
        RecyclerView.LayoutManager layoutManager = null;

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            layoutManager = new GridLayoutManager(this,5);
            }else{
            layoutManager = new GridLayoutManager(this, 3);
        }
        mRecyclerView.setLayoutManager(layoutManager);

        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setHasFixedSize(true);
        if (savedInstanceState != null ){
            if (savedInstanceState.containsKey(MOVIES_LIST_KEY)){
                mSortType = savedInstanceState.getString(SORT_TYPE_KEY);

                ArrayList<Movies> list;
                list = savedInstanceState.getParcelableArrayList(MOVIES_LIST_KEY);
                mAdapter.setmList(list);
                mAdapter.notifyDataSetChanged();

                //scrolled to position
                ((GridLayoutManager) mRecyclerView.getLayoutManager()).scrollToPosition(savedInstanceState.getInt(SCROLL_POSITION_KEY));

            }
        }
        loadMovies(API_DEFAULT_PAGE, mSortType);

        mScrollListener = new RecyclerViewScrolledListener((GridLayoutManager) layoutManager ){
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                Log.d(TAG,"RecyclerViewScrolledListener: Inside ScrollListener . Page: " + page);

                loadMovies(page, mSortType);
                view.post(new Runnable(){


                    @Override
                    public void run() {
                        mAdapter.notifyDataSetChanged();
                    }
                });
            }
        }
        if (savedInstanceState != null){
            if (savedInstanceState.containsKey(CURRENT_PAGE_KEY)){
                mScrollListener.setCurrentPage(savedInstanceState.getInt(CURRENT_PAGE_KEY));
                mScrollListener.setLoading(savedInstanceState.getBoolean(LOADING_KEY));
                mScrollListener.setPreviousTotal(savedInstanceState.getInt(PREVIOUS_TOTAL_ITEM_COUNT_KEY));
                savedInstanceState.clear();
            }
        }
        mRecyclerView.addOnScrollListener(mScrollListener);
    }

    public void loadMovies(final int offset, String mSortType){
        Call<MoviesPage> moviesPageCall = mRoute.getPopular(BuildConfig.API_MOVIE_KEY, offset);

        switch (mSortType){
            case POPULAR_SORT:{
                moviesPageCall = mRoute.getPopular(BuildConfig.API_MOVIE_KEY, offset);
                break;
            }
            case TOP_RATED_SORT:{
                moviesPageCall = mRoute.getTopRated(BuildConfig.API_MOVIE_KEY, offset);
                break;
            }
        }
        moviesPageCall.enqueue(new Callback<MoviesPage>() {
            @Override
            public void onResponse(Call<MoviesPage> call, Response<MoviesPage> response) {
                if (response.isSuccessful()){
                    mAdapter.updateMovies(response.body().getMovies());
                }else{
                    int statusCode = response.code();
                    //handle request errors depending on status code
                    (Toast.makeText(mContext, "Check your connection and try again!", Toast.LENGTH_SHORT)).show();
                }
            }

            @Override
            public void onFailure(Call<MoviesPage> call, Throwable t) {
                //handle request errors depending on status code
                (Toast.makeText(mContext, "Check your connection and try again!", Toast.LENGTH_SHORT)).show();

            }
        });
    }


    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.movies_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.popular_action:
                if (mSortType != POPULAR_SORT){
                    mSortType = POPULAR_SORT;
                    mAdapter.ClearList();
                    mAdapter.notifyDataSetChanged();
                    mScrollListener.reset();
                    loadMovies(API_DEFAULT_PAGE, mSortType);
                }
                break;
            case R.id.top_rated_action:
                if (mSortType != TOP_RATED_SORT){
                    mSortType = TOP_RATED_SORT;
                    mAdapter.ClearList();
                    mAdapter.notifyDataSetChanged();
                    mScrollListener.reset();
                    loadMovies(API_DEFAULT_PAGE, mSortType);
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
